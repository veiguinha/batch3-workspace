# Data Dictionary

| Field Name       | Data Type  | Possible Values             |
|------------------|------------|-----------------------------|
| `Outlook`        | Text       | $\{sunny, overcast, rain\}$ |
| `Temperature`    | Text       | $\{cool, mild, hot\}$       |
| `Humidity`       | Text       | $\{high, normal\}$          |
| `Windy`          | Text       | $\{true, false\}$           |
| `Class` (Target) | Text       | $\{P, N\}$                  |