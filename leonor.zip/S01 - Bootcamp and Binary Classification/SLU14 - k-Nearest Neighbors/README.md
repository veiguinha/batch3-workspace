# Small Learning Unit 14 - k-Nearest Neighbors (kNN)

#### [Presentation](https://docs.google.com/presentation/d/1GQrTWHHp7-W4PNpbnNLRpejDGOsQjM0p-rnf2GrT9TQ/edit?usp=sharing)

# New concepts in this unit

- Key Differentiators of kNN
- A Primer on Distance
- Using kNN


# New tools in this unit

TBD